#!/bin/bash -x
x=100;
y=100;
z=$(( $x + $y ))
echo $z
