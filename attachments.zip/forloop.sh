#!/bin/bash -x

for(( counter=1; counter<=5; counter++))
do
echo -n "$counter"
done
printf "\n"
